package com.example.mytddapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import kotlinx.android.synthetic.main.activity_main.*


/**
 *  Android Test Driven Development
 *  @author Solomon Mayfield
 *  Test Driven Development in Android Studio. Espresso tests can be a fast, convenient way to ensure that an Android app is fully functional. This video tutorial is in Kotlin, although developers can easily substitute Java.
 *
 *
 *
 *
 */

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button.setOnClickListener {
            message.text = "Welcome,${firstName.text} ${lastName.text}!"
        }


    }

}
