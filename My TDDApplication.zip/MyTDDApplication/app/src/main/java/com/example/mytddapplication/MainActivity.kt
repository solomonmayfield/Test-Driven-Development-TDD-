package com.example.mytddapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import kotlinx.android.synthetic.main.activity_main.*


/**
 *  Android Test Driven Development
 *  @author Solomon Mayfield
 *
 *
 *
 *  
 *
 */

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button.setOnClickListener {message.text = "Welcome, Jake Smith"}


    }

}
